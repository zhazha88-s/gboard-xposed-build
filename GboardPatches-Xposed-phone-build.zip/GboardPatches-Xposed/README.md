# Gboard Patches Xposed — diagnostic foundation

**Status: source project / diagnostic build only. This is not a functional port of the upstream feature patches yet.**

Target device details supplied for this port:

- Gboard version: `18.4.1.985164140-release-arm64-v8a`
- Package: `com.google.android.inputmethod.latin`
- Android: 17 / API 37

The upstream project is a **Morphe patch collection**, not an Xposed module. Its current public patch metadata names Gboard `18.0.3.954559732-release-arm64-v8a`; the user's `18.4.1` build is different, so direct compatibility cannot be assumed. Several upstream features are bytecode/resource edits or newly added UI/services, and they cannot be migrated simply by wrapping `.mpp` files.

## What this project currently does

1. Declares LSPosed scope for `com.google.android.inputmethod.latin`.
2. Logs when the hook entry is loaded.
3. Reads and logs the actual installed Gboard version and APK split paths.
4. Asynchronously scans APK DEX entries and logs class names matching feature/flag/settings-related keywords.
5. Writes a candidate class-name report to the Gboard app's external files directory when Android permits it.
6. Uses defensive error handling so a scan failure should not crash Gboard.

## What it does *not* do yet

No upstream feature has been enabled or ported in this build. In particular, it does not yet unlock OCR, advanced voice typing, split keyboard, clipboard modifications, custom symbols, frosted glass, FTP, web clipboard, toolbar additions, or other project features. Runtime classes/methods must be identified on the exact `18.4.1` build before implementing verified hooks.

## Build

1. Install Android Studio and Android SDK Platform 37 (Android 17).
2. Open this directory as a project.
3. Allow Gradle to resolve dependencies. The module uses the legacy Xposed API as `compileOnly`; it is not bundled into the APK.
4. Build `app` → `assembleDebug`.
5. Install `app/build/outputs/apk/debug/app-debug.apk`.

The build has not been executed in this environment because Android SDK/Gradle are not installed and network access to dependency repositories is unavailable. Treat this archive as source code, not as a verified APK.

## Collect diagnostic logs

1. Enable the module in LSPosed, with the Gboard scope selected.
2. Force-stop Gboard or reboot the phone, then invoke the keyboard.
3. Open LSPosed's log viewer and filter for `GboardPatchesXposed` / `[GboardPatchesXposed]`.
4. Save the full log, including `Installed versionName`, `VERSION_MISMATCH`/`TARGET_VERSION_MATCH`, `DEX_CANDIDATE` and `DEX_SCAN_DONE` lines.

The report file, when written, is under the Gboard external-files directory:
`Android/data/com.google.android.inputmethod.latin/files/GboardPatchesXposed/gboard-class-candidates.txt`

## Porting order

Recommended first wave (mostly unlocks of existing UI/flags): cursor trackpad, split keyboard, emoji size, OCR/Scan Text, grammar checker, inline suggestions, Bluetooth microphone and voice typing flags. These still require locating the corresponding version-18.4.1 methods/flag storage and testing each change.

Second wave (new runtime features with larger scope): clipboard enhancements, custom symbols, long-press editing shortcuts, toolbar buttons, floating web search, frosted-glass effect, Web Clipboard and FTP server.

## References

- Upstream patch source: https://github.com/jasonwu1994/Gboard-patches
- Upstream patch metadata: https://github.com/jasonwu1994/Gboard-patches/blob/main/patches-list.json
- LSPosed module scope documentation: https://github.com/LSPosed/LSPosed/wiki/Module-Scope
- Android 17 SDK setup: https://developer.android.com/about/versions/17/setup-sdk

Upstream repository license: GPL-3.0. This diagnostic scaffold is a separate implementation and is not endorsed by the upstream author.
