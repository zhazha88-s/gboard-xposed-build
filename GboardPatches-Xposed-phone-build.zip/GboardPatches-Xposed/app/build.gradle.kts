plugins {
    id("com.android.application")
}

android {
    namespace = "dev.gboardpatches.xposed"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.gboardpatches.xposed"
        minSdk = 26
        // The module itself does not need to opt in to Android 17 behavior changes.
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-diagnostic"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // Compile-only: the installed Xposed/LSPosed framework provides these classes at runtime.
    compileOnly("de.robv.android.xposed:api:82")
}
