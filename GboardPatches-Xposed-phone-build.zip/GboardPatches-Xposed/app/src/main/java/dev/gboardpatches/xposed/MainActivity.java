package dev.gboardpatches.xposed;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 48, 40, 40);
        root.setGravity(Gravity.TOP);

        TextView title = new TextView(this);
        title.setText("Gboard Patches Xposed · 诊断版");
        title.setTextSize(22);
        title.setPadding(0, 0, 0, 24);
        root.addView(title);

        TextView body = new TextView(this);
        body.setText(
            "目标 Gboard：18.4.1.985164140-release-arm64-v8a\n" +
            "目标包名：com.google.android.inputmethod.latin\n" +
            "目标系统：Android 17 / API 37\n\n" +
            "当前版本只用于确认 Hook 是否注入、读取 Gboard 版本并扫描候选类名；" +
            "尚未实现原仓库的功能补丁。\n\n" +
            "使用步骤：\n" +
            "1. 在 LSPosed 中启用本模块并确认作用域包含 Gboard。\n" +
            "2. 重启 Gboard（必要时重启设备）。\n" +
            "3. 打开 Gboard 设置或输入框，触发进程启动。\n" +
            "4. 在 LSPosed 日志中筛选标签 [GboardPatchesXposed]。\n\n" +
            "日志里若显示 VERSION_MISMATCH 或扫描失败，请保留完整日志。\n\n" +
            "说明：需要先取得目标版本实际类/方法信息，才能安全编写功能 Hook。"
        );
        body.setTextSize(16);
        body.setLineSpacing(7, 1f);
        root.addView(body);
        setContentView(root);
    }
}
