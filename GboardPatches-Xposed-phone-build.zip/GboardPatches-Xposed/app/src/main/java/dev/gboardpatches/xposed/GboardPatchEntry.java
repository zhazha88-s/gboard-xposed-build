package dev.gboardpatches.xposed;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;

import dalvik.system.DexFile;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Diagnostic entry only. Does not change Gboard behavior yet.
 * Keep this class defensive: diagnostic failures must never crash the IME process.
 */
public final class GboardPatchEntry implements IXposedHookLoadPackage {
    private static final String TAG = "[GboardPatchesXposed] ";
    private static final String TARGET_PACKAGE = "com.google.android.inputmethod.latin";
    private static final String TARGET_VERSION = "18.4.1.985164140-release-arm64-v8a";
    private static final AtomicBoolean SCAN_STARTED = new AtomicBoolean(false);
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "GboardPatches-DexScan");
        thread.setDaemon(true);
        return thread;
    });

    private static final Pattern INTERESTING = Pattern.compile(
        "(?i)(feature|flag|pref|setting|clipboard|emoji|voice|keyboard|layout|suggest|toolbar|" +
        "trackpad|ocr|grammar|compose|theme|accessibility|split|access.?point|zhuyin|" +
        "symbol|incognito|gesture|editing|frost|websearch|quickinsert)"
    );

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) return;

        log("Hook entry reached. process=" + lpparam.processName
            + ", sdk=" + Build.VERSION.SDK_INT
            + ", fingerprint=" + Build.FINGERPRINT);
        log("This is DIAGNOSTIC-ONLY. No feature patch is being applied.");

        try {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        try {
                            Context context = (Context) param.args[0];
                            if (context == null || !TARGET_PACKAGE.equals(context.getPackageName())) return;
                            logPackageInfo(context);
                            if (SCAN_STARTED.compareAndSet(false, true)) {
                                // During Application.attach, ContextImpl.getApplicationContext()
                                // can still return null. The attach argument itself is usable for
                                // package/APK inspection, so fall back to it rather than passing null
                                // into the background task.
                                Context appContext = null;
                                try {
                                    appContext = context.getApplicationContext();
                                } catch (Throwable t) {
                                    log("getApplicationContext() failed during attach: " + t);
                                }
                                final boolean usedAttachContext = appContext == null;
                                final Context scanContext = usedAttachContext ? context : appContext;
                                log("DEX_SCAN_QUEUING contextClass=" + scanContext.getClass().getName()
                                    + ", usedAttachContextFallback=" + usedAttachContext);
                                try {
                                    EXECUTOR.execute(() -> {
                                        log("DEX_SCAN_THREAD_STARTED contextNull=" + (scanContext == null));
                                        scanDexFiles(scanContext);
                                    });
                                } catch (Throwable t) {
                                    log("Failed to queue DEX scan: " + t);
                                }
                            }
                        } catch (Throwable t) {
                            log("Application.attach inspection failed: " + t);
                        }
                    }
                });
        } catch (Throwable t) {
            log("Failed to hook Application.attach: " + t);
        }
    }

    private static void logPackageInfo(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(TARGET_PACKAGE, 0);
            String versionName = info.versionName == null ? "<null>" : info.versionName;
            long versionCode = Build.VERSION.SDK_INT >= 28
                ? info.getLongVersionCode() : info.versionCode;
            log("Installed versionName=" + versionName + ", versionCode=" + versionCode);
            if (!TARGET_VERSION.equals(versionName)) {
                log("VERSION_MISMATCH: expected " + TARGET_VERSION + "; got " + versionName
                    + ". Keep diagnostics only; do not assume patch compatibility.");
            } else {
                log("TARGET_VERSION_MATCH");
            }

            ApplicationInfo ai = pm.getApplicationInfo(TARGET_PACKAGE, 0);
            log("sourceDir=" + ai.sourceDir);
            if (ai.splitSourceDirs != null) {
                for (String split : ai.splitSourceDirs) log("splitSourceDir=" + split);
            }
            File outDir = context.getExternalFilesDir("GboardPatchesXposed");
            if (outDir != null) log("report directory=" + outDir.getAbsolutePath());
        } catch (Throwable t) {
            log("Package info read failed: " + t);
        }
    }

    private static void scanDexFiles(Context context) {
        if (context == null) {
            log("DEX_SCAN_ABORTED reason=null-context");
            return;
        }
        log("DEX_SCAN_BEGIN contextClass=" + context.getClass().getName()
            + ", thread=" + Thread.currentThread().getName());
        long startedAt = System.currentTimeMillis();
        int inspected = 0;
        int logged = 0;
        BufferedWriter report = null;
        try {
            File dir = context.getExternalFilesDir("GboardPatchesXposed");
            log("DEX_REPORT_DIR " + (dir == null ? "null" : dir.getAbsolutePath()));
            if (dir != null && (dir.exists() || dir.mkdirs())) {
                report = new BufferedWriter(new FileWriter(new File(dir, "gboard-class-candidates.txt"), false));
                report.write("Gboard Patches Xposed diagnostic report\n");
                report.write("targetVersion=" + TARGET_VERSION + "\n");
                report.write("sdk=" + Build.VERSION.SDK_INT + "\n\n");
            }

            ApplicationInfo ai = context.getApplicationInfo();
            String[] paths;
            if (ai.splitSourceDirs == null || ai.splitSourceDirs.length == 0) {
                paths = new String[] { ai.sourceDir };
            } else {
                paths = new String[ai.splitSourceDirs.length + 1];
                paths[0] = ai.sourceDir;
                System.arraycopy(ai.splitSourceDirs, 0, paths, 1, ai.splitSourceDirs.length);
            }

            final int maxLogged = 500;
            for (String path : paths) {
                if (path == null) continue;
                File apkFile = new File(path);
                log("DEX_SCAN_APK_BEGIN path=" + path + ", exists=" + apkFile.exists()
                    + ", canRead=" + apkFile.canRead() + ", bytes=" + apkFile.length());
                int entriesBefore = inspected;
                DexFile dex = null;
                try {
                    dex = new DexFile(path);
                    log("DEX_OPEN_OK path=" + path);
                    Enumeration<String> entries = dex.entries();
                    while (entries.hasMoreElements()) {
                        String className = entries.nextElement();
                        inspected++;
                        if (className == null || !INTERESTING.matcher(className).find()) continue;
                        if (logged >= maxLogged) continue;
                        logged++;
                        String line = className;
                        log("DEX_CANDIDATE " + line);
                        if (report != null) {
                            report.write(line);
                            report.newLine();
                        }
                    }
                    log("DEX_SCAN_APK_DONE path=" + path + ", entries=" + (inspected - entriesBefore));
                } catch (Throwable t) {
                    log("Dex scan failed for " + path + ": " + android.util.Log.getStackTraceString(t));
                } finally {
                    if (dex != null) {
                        try { dex.close(); } catch (Throwable ignored) { }
                    }
                }
            }
            log("DEX_SCAN_DONE inspected=" + inspected + ", candidatesLogged=" + logged
                + ", elapsedMs=" + (System.currentTimeMillis() - startedAt));
            if (report != null) {
                report.write("\ninspected=" + inspected + ", candidatesLogged=" + logged + "\n");
            }
        } catch (Throwable t) {
            log("Top-level dex scan failed: " + android.util.Log.getStackTraceString(t));
        } finally {
            if (report != null) {
                try { report.close(); } catch (IOException ignored) { }
            }
        }
    }

    private static void log(String message) {
        String line = TAG + message;
        try { XposedBridge.log(line); } catch (Throwable ignored) { }
        android.util.Log.i("GboardPatchesXposed", message);
    }
}
