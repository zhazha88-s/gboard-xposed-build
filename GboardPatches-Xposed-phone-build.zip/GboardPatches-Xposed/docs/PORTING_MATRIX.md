# Feature porting matrix (initial planning)

| Group | Upstream feature | Runtime-hook feasibility | Current state |
|---|---|---|---|
| Built-in unlock | Cursor trackpad | Potentially high if gates are ordinary methods/flags | Not implemented; inspect 18.4.1 runtime |
| Built-in unlock | Split keyboard | Potentially high | Not implemented |
| Built-in unlock | Emoji size | Potentially high | Not implemented |
| Built-in unlock | OCR / Scan Text | Medium; may depend on rollout/backend availability | Not implemented |
| Built-in unlock | Grammar checker / Smart Compose | Medium; server-side eligibility may remain | Not implemented |
| Built-in unlock | Bluetooth microphone / advanced voice typing | Medium; backend and device constraints may apply | Not implemented |
| Built-in unlock | Developer options / Flag Editor | Medium-high, but storage/proto layout must be discovered | Not implemented |
| New UI | Long-press editing shortcuts | Medium; needs event and layout hook points | Not implemented |
| New UI | Custom symbols tab | Low-medium; creates custom UI/data | Not implemented |
| New UI/service | Web Clipboard | Low; new local server, pairing, and UI are required | Not implemented |
| New UI/service | FTP server | Low; service, networking, permissions, and UI required | Not implemented |
| Rendering | Frosted Glass | Medium-low; window blur/theme lifecycle integration needed | Not implemented |
| Package patch | Package Rename | Not an ordinary in-place runtime hook; requires a separate APK/install strategy | Not implemented |

“Feasibility” is an engineering estimate, not a claim that a compatible hook point has been found.
