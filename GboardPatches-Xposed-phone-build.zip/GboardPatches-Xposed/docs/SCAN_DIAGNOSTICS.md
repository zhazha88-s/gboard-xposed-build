# DEX scan diagnostics

This build is still diagnostic-only and does not apply Gboard feature patches.

The scanner reports APK paths and enumerates the DEX class names exposed for each APK. It also inventories `classes*.dex` ZIP entries per APK and logs counts per path. The report file is written under the target application's external files directory in `GboardPatchesXposed/gboard-class-candidates.txt` and includes the originating APK path for each matching class.

Useful log markers:
- `DEX_SCAN_SPLIT_COUNT`, `DEX_SCAN_PATH_COUNT`
- `DEX_APK_ENTRY_INDEX` and `DEX_APK_ENTRY_INDEX_FAILED`
- `DEX_OPEN_OK`, `DEX_SCAN_APK_DONE`, `DEX_SCAN_APK_FAILED`
- `DEX_CANDIDATE apk=... class=...`
- `DEX_SCAN_DONE`

Target version check remains `18.4.1.985164140-release-arm64-v8a`. Diagnostic findings are not proof that a particular hook is compatible.
